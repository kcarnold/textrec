/** @format */

import { createReducer, configureStore } from "redux-starter-kit";
import { connect } from "react-redux";
import masterViewFactory from "./MasterViewFactory";

const screens = ["Screen 1", "Screen 2"];

const screensReducer = createReducer(
  { cur: 0, screens },
  {
    next: (state, action) => {
      state.cur += 1;
    },
  }
);

function createTaskState() {
  let store = configureStore({
    reducer: {
      screens: screensReducer,
    },
  });
  // Store metadata as top-level props; it's not worth another reducer.
  store.replaying = false;
  store.spying = false;
  return store;
}

function getCurView(state) {
  return <div>{state.screens.screens[state.screens.cur]}</div>;
}

export function getApp(config) {
  return {
    createTaskState,
    MasterView: masterViewFactory(getCurView),
  };
}
