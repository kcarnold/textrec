/** @format */

import React, { Component } from "react";
import { Provider, connect } from "react-redux";

export const masterViewFactory = getCurView =>
  connect(state => ({
    spying: state.spying,
    curView: getCurView(state),
  }))(
    class MasterView extends Component {
      componentDidUpdate() {
        if (!this.props.spying) {
          window.scrollTo(0, 0);
        }
      }

      render() {
        let { store, dispatch, participantId, spying } = this.props;
        spying = !!spying;
        if (state.replaying) return <div>Loading...</div>;
        return (
          <Provider
            store={store}
            dispatch={dispatch}
            participantId={participantId}
            spying={spying}
          >
            <div className="App">{curView}</div>
          </Provider>
        );
      }
    }
  );

export default masterViewFactory;
