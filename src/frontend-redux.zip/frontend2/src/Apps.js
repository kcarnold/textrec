/**
 * @format
 */

function getApp(config) {
  return require("./SkelTask").getApp();
  // if (config === "gcap") {
  //   return require("./GatedCapTask");
  // }
  // if (config === "cue") {
  //   return require("./CueTasks");
  // }
}

export default getApp;
